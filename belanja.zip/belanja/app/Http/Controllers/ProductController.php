<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Keranjang;
use App\Models\Pesanan;
use Session;
use Illuminate\Support\Facades\DB;
class ProductController extends Controller
{
    //
    function index(){

        $data = Product::all();

        return view('product',['products'=>$data]);
    }

    function detail($id){
        $data = Product::find($id);
        return view('detail',['product'=>$data]);
    }

    function search(Request $req){
        $data=Product::
        where('nama','like', '%'.$req->input('query').'%')
        ->get();
        return view('search',['products'=>$data]);
    }

    function addToKeranjang(Request $req){
        if ($req->session()->has('user'))
        {
            $keranjang= new Keranjang;
            $keranjang->user_id=$req->session()->get('user')['id'];
            $keranjang->product_id=$req->product_id;
            $keranjang->save();
            return redirect('/');
        }
        else
        {
            return redirect('/login');
        }
        
    }

    static function keranjangItem(){
        $userId=Session::get('user')['id'];
        return Keranjang::where('user_id',$userId)->count();
    }   

    function keranjangList(){
        $userId=Session::get('user')['id'];
        $products= DB::table('keranjang')
        ->join('products','keranjang.product_id','=','products.id')
        ->where('keranjang.user_id',$userId)
        ->select('products.*','keranjang.id as keranjang_id')
        ->get();

        return view('keranjanglist',['products'=>$products]);
    }

    function hapusKeranjang($id){
        
        Keranjang::destroy($id);
        return redirect('keranjanglist');
    }

    function pesanSekarang(){
        $userId=Session::get('user')['id'];
        $total= $products= DB::table('keranjang')
        ->join('products','keranjang.product_id','=','products.id')
        ->where('keranjang.user_id',$userId)
        ->sum('products.harga');

        return view('pesansekarang',['total'=>$total]);
    }

    function orderPlace(Request $req){

        $userId=Session::get('user')['id'];
        $allKeranjang= Keranjang::where('user_id',$userId)->get();
        foreach($allKeranjang as $keranjang)
        {
            $pesanan = new Pesanan;
            $pesanan->product_id=$keranjang['product_id'];
            $pesanan->user_id=$keranjang['user_id'];
            $pesanan->status="pending";
            $pesanan->metode_pembayaran=$req->pembayaran;
            $pesanan->status_pembayaran="pending";
            $pesanan->alamat=$req->alamat;
            $pesanan->save();
            Keranjang::where('user_id',$userId)->delete();
        }
        $req->input();
        return redirect('/');
    }

    function pesananSaya()
    {
        $userId=Session::get('user')['id'];
        $pesanans= DB::table('pesanans')
        ->join('products','pesanans.product_id','=','products.id')
        ->where('pesanans.user_id',$userId)
        ->get();

        return view('pesanansaya',['pesanans'=>$pesanans]);
    }
    
}
