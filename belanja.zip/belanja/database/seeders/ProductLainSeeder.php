<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductLainSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([

            [
                'nama'=>'Lenovo Ideapad 320',
                "harga"=>"3800000",
                "deskripsi"=>"Windows 10, Processor i3, Memory(RAM) 8 GB, Hardisk 1 TB",
                "kategori"=>"Reguler",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/Lenovo_IdeaPad_320/Lenovo_IdeaPad_320_L_1.jpg"
    
            ],

            [
                'nama'=>'Apple MacBook Pro MD101ZA/A',
                "harga"=>"13700000",
                "deskripsi"=>"Mac OSX v10.7, Processor i5, Memory(RAM) 4 GB, Hardisk 500 GB",
                "kategori"=>"Premium",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/Apple_MacBook_Pro_MD101TH_A/Apple_MacBook_Pro_MD101TH_A_L_1.jpg"
    
            ],

            [
                'nama'=>'Dell Alienware 15 R3',
                "harga"=>"24000000",
                "deskripsi"=>"Windows 10, Processor i7, Memory(RAM) 32 GB, Hardisk 1 TB",
                "kategori"=>"Gaming",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/Dell_Alienware_15_R3/Dell_Alienware_15_R3_L_1.jpg"
    
            ],

            [
                'nama'=>'Acer Predator 21 X',
                "harga"=>"45000000",
                "deskripsi"=>"Windows 10 Home, Processor i7, Memory(RAM) 64 GB, Hardisk 2 TB",
                "kategori"=>"Gaming",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/Acer_Predator_21_X/Acer_Predator_21_X_L_1.jpg"
    
            ],

            

            [
                'nama'=>'ASUS ROG Zephyrus G14 (GA401)',
                "harga"=>"14899000",
                "deskripsi"=>"Windows 10 Home, Processor AMD Ryzen 9 4900HS, Memory(RAM) 16 GB, Hardisk 512 GB",
                "kategori"=>"Gaming",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/ASUS_ROG_Zephyrus_G14/ASUS_ROG_Zephyrus_G14_L_1.jpg"
    
            ],

            

            [
                'nama'=>'HP ENVY x360',
                "harga"=>"15450000",
                "deskripsi"=>"Windows 10 Home, Processor AMD Ryzen 7 2700U, Memory(RAM) 8 GB, Hardisk 512 GB",
                "kategori"=>"Premium",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/HP_ENVY_x360_13/HP_ENVY_x360_13_L_1.jpg"
    
            ],

            

            [
                'nama'=>'MSI Alpha 15',
                "harga"=>"16800000",
                "deskripsi"=>"Windows 10 Home, Processor AMD Ryzen 7, Memory(RAM) 64 GB, Hardisk 1 TB",
                "kategori"=>"Gaming",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/MSI_Alpha_15/MSI_Alpha_15_L_1.jpg"
    
            ],

            [
                'nama'=>'HUAWEI MateBook D 14',
                "harga"=>"10499000",
                "deskripsi"=>"Windows 10 Home, Processor core i7, Memory(RAM) 16 GB, Hardisk 512 GB",
                "kategori"=>"Premium",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/HUAWEI_MateBook_D_14_2020/HUAWEI_MateBook_D_14_2020_L_1.jpg"
    
            ],

            [
                'nama'=>'MSI GF63 Thin 9SC',
                "harga"=>"8999000",
                "deskripsi"=>"Windows 10 Home, Processor Acore i5, Memory(RAM) 4 GB, Hardisk 256 GB",
                "kategori"=>"Reguler",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/MSI_GF63_Thin_9SC/MSI_GF63_Thin_9SC_L_1.jpg"
    
            ],

            [
                'nama'=>'ASUS Laptop E410MA',
                "harga"=>"4999000",
                "deskripsi"=>"Windows 10 Home, Processor Celeron Dual Core, Memory(RAM) 4 GB, Hardisk 512 GB",
                "kategori"=>"Reguler",
                "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/ASUS_Laptop_E410MA/ASUS_Laptop_E410MA_L_1.jpg"
    
            ]

    ]);
    }
}
