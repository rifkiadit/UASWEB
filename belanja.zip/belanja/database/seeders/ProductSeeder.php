<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([

                [
                    'nama'=>'Asus',
                    "harga"=>"3000000",
                    "deskripsi"=>"Intel core 2 duo",
                    "kategori"=>"Notebook",
                    "galeri"=>"https://foto.kontan.co.id/G_1Eu4QHBhBpzm1OfcHukHLd_-I=/smart/2020/09/23/1918940036p.jpg"
        
                ],

                [
                    'nama'=>'HP',
                    "harga"=>"9000000",
                    "deskripsi"=>"Intel core i7",
                    "kategori"=>"Laptop",
                    "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/HP_14_ck1018tx/HP_14_ck1018tx_L_1.jpg"
        
                ],

                [
                    'nama'=>'Asus',
                    "harga"=>"5000000",
                    "deskripsi"=>"Intel core i3",
                    "kategori"=>"Notebook",
                    "galeri"=>"https://d2pa5gi5n2e1an.cloudfront.net/webp/global/images/product/laptops/ASUS_14_M409BA/ASUS_14_M409BA_L_1.jpg"
        
                ]

        ]);
    }
}
