<?php $__env->startSection("content"); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <img class="detail-img" src="<?php echo e($product['galeri']); ?>" alt="">
        </div>
        <div class="col-sm-6">
            <h2><?php echo e($product['nama']); ?></h2>
            <h4>Harga : <?php echo e($product['harga']); ?></h3>
            <h6>Deskripsi : <?php echo e($product['deskripsi']); ?></h6>
            <h6>Kategori : <?php echo e($product['kategori']); ?></h6>
            <br><br>
            <form action="/add_to_keranjang" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value=<?php echo e($product['id']); ?>>
            <button class="btn btn-primary">Tambahkan ke Keranjang</button>
            </form>
            <br><br>

            <br><br>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/detail.blade.php ENDPATH**/ ?>