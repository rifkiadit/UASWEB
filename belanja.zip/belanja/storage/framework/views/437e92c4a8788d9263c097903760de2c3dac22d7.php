
<?php $__env->startSection("content"); ?>
<div class="container custom-product">
    <div class="col-sm-10">
    <div class="trending-wrapper">
    <h4>Pesanan Saya</h4>

    <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row search-item keranjang-list-devider">
        <div class="col-sm-3">
            <a href="detail/<?php echo e($item->id); ?>">
                <img class="trending-image" src="<?php echo e($item->galeri); ?>">
            </a>
        </div>
        <div class="col-sm-4">
        <div class="">
            <h2>Nama : <?php echo e($item->nama); ?></h2>
            <h5>Status Pengiriman : <?php echo e($item->status); ?></h5>
            <h5>Alamat : <?php echo e($item->alamat); ?></h5>
            <h5>Status Pembayaran : <?php echo e($item->status_pembayaran); ?></h5>
            <h5>Metode Pembayaran : <?php echo e($item->metode_pembayaran); ?></h5>
        </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/pesanansaya.blade.php ENDPATH**/ ?>