
<?php $__env->startSection("content"); ?>
<div class="container custom-product">
    <div class="col-sm-4">
    <div class="trending-wrapper">
    <h4>Hasil untuk produk</h4>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="search-item">
    <a href="detail/<?php echo e($item['id']); ?>">
      <img class="trending-image" src="<?php echo e($item['galeri']); ?>">
      <div class="">
        <h2><?php echo e($item['nama']); ?></h2>
        <h5><?php echo e($item['deskripsi']); ?></h5>
      </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/search.blade.php ENDPATH**/ ?>