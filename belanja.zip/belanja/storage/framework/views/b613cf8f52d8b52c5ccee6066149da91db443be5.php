
<?php $__env->startSection("content"); ?>
<div class="container custom-login">
    <div class="row">
        <div class="col-sm-4 offset-md-4">
            <form action="register" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Username</label>
                    <input type="text" name="nama" class="form-control" id="exampleInputEmail1" placeholder="Username">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Masukkan Email</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email" aria-describedby="emailHelp">
                    <div id="emailHelp" class="form-text">Kami tidak akan membagikan email kepada siapapun.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Masukkan Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/register.blade.php ENDPATH**/ ?>