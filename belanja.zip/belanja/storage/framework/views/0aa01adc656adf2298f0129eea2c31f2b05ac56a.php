<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="row" style="margin-top: 55px">
            <div class="card" style="max-width: 320px; margin-left:40px" >
                <div class="card-header">
                    Our Teams
                </div>
                <div class="card-body" style="text-align: center" style="line-height: 0.2">
                    <img src="images/profilArif2.jpg" width="172" height="180" style="border-radius: 50%; padding-bottom:8px">
                    <h6><blockquote>
                        Mohamad Arif Muharam
                    </blockquote>
                    <blockquote style="line-height: 0.2">
                        19552011036
                    </blockquote></h6>
                    <p>Mahasiswa Prodi Teknik Informatika Semester 4</p>
                </div>
                <div class="card-footer">
                    Sekolah Tinggi Teknologi Bandung
                </div>
            </div>



            <div class="card" style="max-width: 320px; margin-left:50px">
                <div class="card-header">
                    Our Teams
                </div>
                <div class="card-body" style="text-align: center" style="line-height: 0.2">
                    <img src="images/profilRifki.jpg" width="172" height="180" style="border-radius: 50%; padding-bottom:8px">
                    <h6><blockquote>
                        Rifki Aditya Nugraha
                    </blockquote>
                    <blockquote style="line-height: 0.2">
                        19552011183
                    </blockquote></h6>
                    <p>Mahasiswa Prodi Teknik Informatika Semester 4</p>
                </div>
                <div class="card-footer">
                    Sekolah Tinggi Teknologi Bandung
                </div>
            </div>

            <div class="card" style="max-width: 320px; margin-left:50px">
                <div class="card-header">
                    Our Teams
                </div>
                <div class="card-body" style="text-align: center"style="line-height: 0.2">
                    <img src="images/profilTatan.jpg" width="162" height="180" style="border-radius: 50%; padding-bottom:8px">
                    <h6><blockquote>
                        Tatan Tanuwijaya
                    </blockquote>
                    <blockquote style="line-height: 0.2">
                        19552011132
                    </blockquote></h6>
                    <p>Mahasiswa Prodi Teknik Informatika Semester 4</p>
                </div>
                <div class="card-footer">
                    Sekolah Tinggi Teknologi Bandung
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/About.blade.php ENDPATH**/ ?>