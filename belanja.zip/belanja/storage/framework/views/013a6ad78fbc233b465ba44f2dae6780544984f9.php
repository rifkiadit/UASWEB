<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laptopers</title>

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <!-- Optional theme -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</head>
<body>
    <?php echo e(View::make('header')); ?>

    <?php echo $__env->yieldContent('content'); ?>
    <?php echo e(View::make('footer')); ?>

</body>
<style>
    header{
    background-image: url('images/background2.jpg');
    color: #ffffff;
    padding-top: 25px;
    padding-bottom: 35px;
    min-height: 365px;
    margin-bottom: 25px
    }

    .custom-login{
        height: 500px;
        padding-top: 100px;

    }
    img.slider-img{
        height: 400px !important;
        padding-top: 20px;
        z-index: 1;

    }
    .custom-product{
        height: 600px
    }
    .trending-image{
        height: 100px;
    }
    .trending-item{
        float: left;
        width: 20%;
    }
    .detail-img{
        height: 200px;
    }
    .search-box{
        width: 500px !important
    }
    .keranjang-list-devider{
        border-bottom: 1px solid #ccc;
        margin-bottom: 20px;
        padding-bottom: 20px;
    }
    .ft{
        float: center;
        background-color: black;
        color: #ffff;
        margin-top: 200px;
        padding-top: 10px;
        padding-right: 30px;
        padding-bottom: 10px;
        padding-left: 80px;
    }
    .icon.help {
    width: 30px;
    height: 30px;
    background-position: -132px 0px;
    cursor: pointer;
    background-size: 200px auto;
}
    .textHeader{
        text-align: left;
        line-height:1.1;
        margin:0 auto 38px;
        padding-top:100px;
        padding-left:105px;
        font-family:sans-serif;
        max-width: 415px;
        float: left;
    }

</style>
</html>
<?php /**PATH C:\xampp\htdocs\belanja\resources\views/master.blade.php ENDPATH**/ ?>