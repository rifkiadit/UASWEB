
<?php $__env->startSection("content"); ?>
<div class="container custom-product">
    <div class="col-sm-10">
    <table class="table">
  <tbody>
    <tr>
      <td>Harga</td>
      <td>Rp. <?php echo e($total); ?></td>
    </tr>
    <tr>
      <td>Pajak</td>
      <td>Rp. 0</td>
    </tr>
    <tr>
      <td>Ongkos Kirim</td>
      <td>Rp. 7000</td>
    </tr>
    <tr>
      <td>Total Harga</td>
      <td>Rp. <?php echo e($total+7000); ?></td>
    </tr>
  </tbody>
</table>
        <div>
            <form action="/orderplace" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <textarea name="alamat" type="email" placeholder="Masukkan Alamat" class="form-control" aria-describedby="emailHelp"></textarea>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="fw-bold">Metode Pembayaran</label><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;Transfer Bank</span><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;Cicilan Kartu Kredit</span><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;COD</span><br><br>
            </div>
            <button type="submit" class="btn btn-primary">Pesan Sekarang</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belanja\resources\views/pesansekarang.blade.php ENDPATH**/ ?>