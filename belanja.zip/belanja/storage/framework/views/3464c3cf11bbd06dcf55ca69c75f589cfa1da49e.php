<?php
use App\Http\Controllers\ProductController;
$total=0;
if(Session::has('user'))
{
$total = ProductController::keranjangItem();
}

?>


<nav class="navbar navbar-expand-lg navbar-light bg-light" style="position: fixed; width:100%; z-index:100" >
  <div class="container-fluid">
    <a class="navbar-brand" href="/" >
    <img src="<?php echo e(url('images/logo2.png')); ?>" width="130" alt=""></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/">Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/pesanansaya">Pesanan</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/keranjanglist">Keranjang(<?php echo e($total); ?>)</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/about">About</a>
          </li>
        <li class="nav-item">
          <a class="nav-link" href="/register">Register</a>
        </li>

        <?php if(Session::has('user')): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo e(Session::get('user')['nama']); ?>

          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="/logout">Logout</a></li>
          </ul>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link" href="/login">Login</a>
        </li>
        <?php endif; ?>
      </ul>
      <form action= "/search"class="d-flex">
        <input class="form-control me-2 search-box" name="query" type="search" placeholder="Cari Produk..." aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Cari</button>
      </form>
    </div>
  </div>
</nav>

<header id="header">
<div class="textHeader">
    <h1 >Laptop</h1>
    <p>Cari kebutuhan perangkat anda disini dan dapatkan penawaran spesial</p>
    <button class="btn btn-outline-success">Belanja</button>
</div>

</header>

<?php /**PATH C:\xampp\htdocs\belanja\resources\views/header.blade.php ENDPATH**/ ?>