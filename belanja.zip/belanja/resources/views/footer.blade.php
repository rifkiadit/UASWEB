<footer class="ft">  
Copyright ©2021 Laptopers.  By <span style="color:gray">Mohamad Arif Muharam, Tatan Tanuwijaya, Rifki Aditya Nugraha</span>
</footer>  
