@extends('master')
@section("content")
<div class="container custom-product">
    <div class="col-sm-10">
    <table class="table">
  <tbody>
    <tr>
      <td>Harga</td>
      <td>Rp. {{$total}}</td>
    </tr>
    <tr>
      <td>Pajak</td>
      <td>Rp. 0</td>
    </tr>
    <tr>
      <td>Ongkos Kirim</td>
      <td>Rp. 7000</td>
    </tr>
    <tr>
      <td>Total Harga</td>
      <td>Rp. {{$total+7000}}</td>
    </tr>
  </tbody>
</table>
        <div>
            <form action="/orderplace" method="POST">
            @csrf
            <div class="mb-3">
                <textarea name="alamat" type="email" placeholder="Masukkan Alamat" class="form-control" aria-describedby="emailHelp"></textarea>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="fw-bold">Metode Pembayaran</label><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;Transfer Bank</span><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;Cicilan Kartu Kredit</span><br><br>
                <input type="radio" value="cash" name="pembayaran"><span>&nbsp;&nbsp;&nbsp;COD</span><br><br>
            </div>
            <button type="submit" class="btn btn-primary">Pesan Sekarang</button>
            </form>
        </div>
    </div>
</div>
@endsection