@extends('master')
@section("content")

<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <img class="detail-img" src="{{$product['galeri']}}" alt="">
        </div>
        <div class="col-sm-6">
            <h2>{{$product['nama']}}</h2>
            <h4>Harga : {{$product['harga']}}</h3>
            <h6>Deskripsi : {{$product['deskripsi']}}</h6>
            <h6>Kategori : {{$product['kategori']}}</h6>
            <br><br>
            <form action="/add_to_keranjang" method="POST">
            @csrf
            <input type="hidden" name="product_id" value={{$product['id']}}>
            <button class="btn btn-primary">Tambahkan ke Keranjang</button>
            </form>
            <br><br>

            <br><br>
        </div>
    </div>
</div>
@endsection
